import React, { Component } from 'react'

// 考试管理
 class Examination extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default Examination