import React, { Component } from 'react';

class Userlist extends Component {
    state = {  }
    render() {
        return (
          <div>
              Userlist
          </div>
        );
    }
}

export default Userlist;